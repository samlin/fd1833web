package com.fd.javabase.com.fd.javabae.util;

public class P {
    private P() {
    }

    public static void p(String string)  {
        System.out.println(string);
    }

    public static void p(int i) {
    }
}
