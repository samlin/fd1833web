package com.fd.javabase.designpattern.command;

public interface Command {
    void execute();
}
