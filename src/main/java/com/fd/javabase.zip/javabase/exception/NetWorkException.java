package com.fd.javabase.exception;

public class NetWorkException extends RuntimeException {
    public NetWorkException() {
    }

    public NetWorkException(String message) {
        super(message);
    }
}
